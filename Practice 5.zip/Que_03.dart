// Get the current working directory
import 'dart:io';
void main() {
  String curr = Directory.current.path;
  print('Current working directory: $curr');
}
