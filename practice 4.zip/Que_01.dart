// Create a list of names and print all names using list.
void main() {
    List<String>s =['mahmudulsakib2019','ecnarwala','tourist','Fahmi_nafi_46'];
    for(var i in s) {
        print(i);
    }
}
