// Create a set of fruits and print all fruits using loop.
void main() {
    Set<String>s = {'Apple','Banana','Carrot','Tangerin'};
    for(var i in s) {
        print(i);
    }
}
